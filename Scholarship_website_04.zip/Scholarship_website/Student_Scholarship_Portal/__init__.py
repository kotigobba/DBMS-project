from flask import Flask


app = Flask(__name__)
from Student_Scholarship_Portal import routes