from Student_Scholarship_Portal import app
from flask import render_template, redirect, url_for,request
from flask_mail import Mail,Message
import smtplib 

app.config['SECRET_KEY']='abc'
app.config['MAIL_SERVER']='smtp.gmail.com'
app.config['MAIL_PORT']=465
app.config['MAIL_USERNAME']='jaatregang999@gmail.com'
app.config['MAIL_PASSWORD']='tbzegkbvxcqmbrzp'
app.config['MAIL_USE_TLS']=False
app.config['MAIL_USE_SSL']=True
mail=Mail(app)

@app.route("/")
@app.route('/home')
def home_page():
    return render_template('home.html')

@app.route("/login")
def login_page():
    return render_template('login.html')

@app.route("/register")
def register_page():
    
    return render_template('register.html')

@app.route('/test',methods=['GET','POST'])
def test():
    if request.method =='POST': 
        a=request.form['name']
        b=request.form['phone']
        c=request.form['email']
        d=request.form['password']
        e=request.form['confirm-password']      
        with smtplib.SMTP("smtp.gmail.com", port=587) as connection:
            connection.starttls()
            connection.login(user='jaatregang999@gmail.com', password='tbzegkbvxcqmbrzp')
            connection.sendmail(
                from_addr='jaatregang999@gmail.com',
                to_addrs='jaatregang999@gmail.com',
                msg=f'''Subject:conformation mail\n\n THANK YOU FOR REGISTERING!!
                        NAME: {a}
                       PHONE: {b}
                      E-MAIL: {c}
                        PASS: {d}'''
            )
            connection.close()
        
        return "MAIL SENT"

@app.route("/contact")
def contact_page():
    return render_template('contact.html')

@app.route("/about")
def about_page():
    return render_template('about.html')

@app.route("/principal")
def principal_page():
    return render_template('principal.html')

@app.route("/vice")
def vice_page():
    return render_template('vice.html')

@app.route("/qa")
def QA_page():
    return render_template('qa.html')

@app.route("/dashboard")
def scholarship_page():
    return render_template('scholarship.html')

@app.route("/detail")
def detail_page():
    return render_template('detail.html')

@app.route("/faq")
def faq_page():
    return render_template('faq.html')