
if ($('title').html() === '\nSchemes and Scholarships\n') {

    // To display the disclaimer when dashboard is loaded

    $(window).ready(function () {
        if (sessionStorage.getItem('#myModal') !== 'true') {
            $('#myModal').modal('show');
            sessionStorage.setItem('#myModal', 'true');
        }
    });

}

if ($('title').html() === '\nHome Page\n') {

    // To display the disclaimer when home page is loaded

    $(window).ready(function () {
        if (sessionStorage.getItem('#myModal') !== 'true') {
            $('#myModal').modal('show');
            sessionStorage.setItem('#myModal', 'true');
        }
    });

}

if ($('title').html() === '\nLogin Page\n') {

    // To toggle the visibility of the password

    const loginPassword = $("#login-password");

    $("#toggleLoginPassword").click(function () {
        // toggle the type attribute
        const loginPasswordType = loginPassword.attr("type") === "password" ? "text" : "password";
        loginPassword.attr("type", loginPasswordType);

        // toggle the icon
        this.classList.toggle("fa-eye");
    });

}

if ($('title').html() === '\nRegister Page\n') {

    // To toggle the visibility of the password

    const registerPassword = $("#register-password");
    const confirmPassword = $("#confirm-password");

    $("#toggleRegisterPassword").click(function () {
        // toggle the type attribute
        const registerPasswordType = registerPassword.attr("type") === "password" ? "text" : "password";
        registerPassword.attr("type", registerPasswordType);

        // toggle the icon
        this.classList.toggle("fa-eye");
    });

    $("#toggleConfirmPassword").click(function () {
        // toggle the type attribute
        const confirmPasswordType = confirmPassword.attr("type") === "password" ? "text" : "password";
        confirmPassword.attr("type", confirmPasswordType);

        // toggle the icon
        this.classList.toggle("fa-eye");
    });

}